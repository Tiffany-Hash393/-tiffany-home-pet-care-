TIFFANY'S HOME & PET CARE WEBSITE
=================================

Included:
- index.html: the complete responsive website.

The site is designed for Tiffany's Home & Pet Care in Scottsdale, Arizona.
It uses a cream, sage green, and gold palette and includes click-to-call and
click-to-text buttons for 602-672-0049. No email address is shown.

FREE PUBLISHING OPTION: GITHUB PAGES
1. Create or sign in to a GitHub account at https://github.com/
2. Create a new PUBLIC repository (for example: tiffany-home-pet-care).
3. Upload index.html to the repository's top/root level.
4. Open the repository's Settings > Pages.
5. Under "Build and deployment", choose "Deploy from a branch".
6. Choose the main branch and /(root), then save.
7. Wait for GitHub Pages to publish the site; the URL will appear in Settings > Pages.

Official guide: https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages

Notes:
- GitHub Pages hosting can be used for free with a public repository.
- A custom domain name is optional and usually costs extra.
- The hero image currently loads from Unsplash, so an internet connection is needed
  to display that photo.
- Review the wording and service list before publishing, and only offer services
  you are comfortable providing.
